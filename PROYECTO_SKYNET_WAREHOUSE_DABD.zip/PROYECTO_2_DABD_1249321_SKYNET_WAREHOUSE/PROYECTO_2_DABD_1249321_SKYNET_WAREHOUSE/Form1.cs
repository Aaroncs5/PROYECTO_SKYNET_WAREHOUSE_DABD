﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
// Seagregar nuevas librerias para poder ejecutar funciones y objetos en el código.
using System.IO; //Esta permitira implematar que el archivo "csv".
using System.Reflection;

namespace PROYECTO_2_DABD_1249321_SKYNET_WAREHOUSE
{
    public partial class Form1 : Form
    {
        //Variables_globales
        string[,] configuracion;
        int[,] capacidad;
        int filas = 0;
        int columnas = 0;
        //string estanteria = "";
        string tipo_robot = "";
        int cont_rs = 1, cont_rh = 1, cont_rn = 1;
        string nombre_picture = "";
        bool pasillo = true;

        //string[,] movimiento;
        //int filas_movimiento = 0;



        public Form1()
        {
            InitializeComponent();
        }
        public string LeerArchivo(ref bool estado_accion)
        {
            estado_accion = false;
            try
            {
                //Abre un navegador para buscar el archivo
                MessageBox.Show("Busque el archivo donde encuetra su configuración");
                string FileToRead = "";
                //openFileDialog1.ShowDialog();
                FileToRead = "C:\\Users\\aaron\\Desktop\\PROYECTO2PROGRA\\ProyectoC.csv";
                //lee y decompone el archivo en lineas
                string conf = "";
                using (StreamReader ReaderObject = new StreamReader(FileToRead))
                {
                    string Line;
                    int contador = 0;
                    //lee cada linea del archivo 
                    while ((Line = ReaderObject.ReadLine()) != null)
                    {

                        //un contador para poder obtener el numero de filas al momento de leer la primera linea, esto lo hace al contar los espacios en blanco 
                        if (contador == 0)
                        {
                            //agrega un espacio en blanco(se pegan las linea si no se coloca el espacio en blanco)y la linea leida del archivo
                            conf += Line + ",";
                            //por cada linea leida suma una columna
                            filas++;
                            for (int l = 0; l < conf.Length; l++)
                            {
                                if (conf[l].ToString() == "," || conf[l].ToString() == "")
                                {
                                    columnas++;
                                }
                            }
                            contador++;

                        }
                        //por cada linea leida suma una columna
                        else
                        {
                            conf += Line + ",";
                            filas++;

                        }
                    }
                    //verifica que no exeda de los limites y tenga el minimo de de filas y columnas 
                    if (filas > 10 || columnas > 10 || filas == 0 || columnas == 0)
                    {
                        MessageBox.Show("Configuracion invalida, Verifique que tenga 1 columnas y 1 filas como minimo o 10 columnas y 10 filas como maximo en la configuracion");
                        Application.Exit();

                    }

                }
                //con esto validamos que se leyó el archivo
                if (conf != "")
                {
                    configuracion = new string[filas, columnas];
                    capacidad = new int[filas, columnas];
                    estado_accion = true;
                }
                return conf;
            }
            catch
            {
                estado_accion = false;
                return "";
            }
        }
        /*public void LlenarMatrizMovimiento()
        {
            movimiento = new string[filas_movimiento, 5];
            int fil = 0;
            int col = 0;

            for (int n = 0; n < movimiento.GetLength(0); n += 0)
            {

                if (configuracion[fil, col] == "C" || configuracion[fil, col] == "N" || configuracion[fil, col] == "F")
                {

                    movimiento[n, 0] = fil.ToString();
                    movimiento[n, 1] = col.ToString();
                    movimiento[n, 2] = capacidad[fil, col].ToString();
                    movimiento[n, 3] = configuracion[fil, col];
                    movimiento[n, 4] = "0";
                    n++;

                }
                col++;
                if (col == columnas)
                {
                    fil++;
                    col = 0;
                }
                if (fil == filas)
                {
                    break;
                }


            }
        }
        */

        /*private void LlenarMatrizA()
        {
            MatrizBodega.Width = 100 * columnas + 100;
            MatrizBodega.Height = 100 * filas + 100;
            for (int y = 0; y < columnas; y++)
            {
                DataGridViewColumn columnas_grid = new DataGridViewImageColumn();
                MatrizBodega.Columns.Add(columnas_grid);
            }
            MatrizBodega.Rows.Add(filas);

            for (int y = 0; y < filas; y++)
            {
                MatrizBodega.Rows[y].HeaderCell.Value = y.ToString();

                for (int x = 0; x < columnas; x++)
                {
                    MatrizBodega.Rows[y].Cells[x].Value = CargarImagen(configuracion[y, x]);
                    MatrizBodega.Rows[y].Height = 80;
                    MatrizBodega.Columns[x].Width = 80;
                }
            }
        
        }
        */

        private void CargarConfiguracion()
        {
            //filas = 0;
            //columnas = 0;
            //filas_movimiento = 0;
            bool estado = false;
            string cadena_conf = LeerArchivo(ref estado).ToString();
            string cadena_guardar = "";
            int posicion_matrizx = 0;
            int posicion_matrizy = 0;
            int capacidad_guardar = 10;
            if (estado)
            {

                try
                {  //decompne la cadena de caracteres para llenar la matriz
                    for (int i = 0; i < cadena_conf.Length; i++)
                    {
                        if (cadena_conf[i].ToString() == ",")
                        {
                            cadena_guardar = "";
                            posicion_matrizx++;
                        }
                        else
                        {
                            cadena_guardar += cadena_conf[i].ToString();
                        }
                        //guarda el caracter en la matriz
                        if (cadena_guardar != "," && cadena_guardar != "")
                        {
                            if (cadena_guardar.ToUpper().Contains("O") || cadena_guardar.ToUpper().Contains("C") || cadena_guardar.ToUpper().Contains("N") || cadena_guardar.ToUpper().Contains("F") || cadena_guardar.ToUpper().Contains("P"))
                            {
                                configuracion[posicion_matrizy, posicion_matrizx] = cadena_guardar.Substring(0, 1);
                            }
                            if (cadena_guardar == "R++" || cadena_guardar == "R+-" || cadena_guardar == "R--")
                            {
                                configuracion[posicion_matrizy, posicion_matrizx] = cadena_guardar.Substring(0, 3);
                            }
                      
                        }
                        //detiene el conteo de columnas al terminar una fila 
                        if (posicion_matrizx == columnas)
                        {
                            posicion_matrizy++;
                            posicion_matrizx = 0;
                        }
                        //rompe el bucle si llega al limite de filas 
                        if (posicion_matrizy == filas)
                        {
                            //LlenarMatrizMovimiento();
                            break;

                        }
                    }
                    MessageBox.Show("Configuracion cargada exitosamente", "GESTOR BODEGA", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    //descompone la matriz para colorear los picturebox
                    for (int y = 0; y < filas; y++)
                    {
                        for (int x = 0; x < columnas; x++)
                        {
                            string dato_configuracion = configuracion[y, x].ToString();
                            if (dato_configuracion == "R++" ||dato_configuracion == "R+-" || dato_configuracion == "R--")
                            {
                                // utliza reflexion para poder convertir un string a picturebox ya que tienen un nombre que tiene la raiz en común
                                nombre_picture = "PB_" + y.ToString() + "_" + x.ToString();
                                PictureBox Picturebx = this.Controls.Find(nombre_picture, true).FirstOrDefault() as PictureBox;
                                Picturebx.BackColor = Codigo_Color("P", ref pasillo);
                                Picturebx.Enabled = pasillo;
                                Picturebx.Visible = true;
                                //añade picture box en tiempo de ejecicion para poder añadir los robors que el usuario queira
                                int posx = Picturebx.Location.X;
                                int posy = Picturebx.Location.Y;
                                Tipo_Robot(dato_configuracion, ref tipo_robot); 
                                PictureBox robot = new PictureBox();
                                Cargar_imagen_Tipo_Robot(dato_configuracion, ref robot, posx, posy);
                                this.Controls.Add(robot);
                                robot.BringToFront();
                            }

                            else
                            {
                                // utliza reflexion para poder convertir un string a picturebox ya que tienen un nombre que tiene la raiz en común
                                nombre_picture = "PB_" + y.ToString() + "_" + x.ToString();
                                PictureBox Picturebx = this.Controls.Find(nombre_picture, true).FirstOrDefault() as PictureBox;
                                Picturebx.BackColor = Codigo_Color(dato_configuracion, ref pasillo);
                                Picturebx.Enabled = pasillo;
                                Picturebx.Visible = true;
                              
                            }

                        }

                    }
                    MessageBox.Show("Configuracion cargada exitosamente", "GESTOR BODEGA", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
            }
            else
            {
                MessageBox.Show("El archivo que contiene la configuracion no se encuentra", "GESTOR BODEGA", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
            }

        }
        //funcion que retorna colores de pende el tipo de cuadro
        private Color Codigo_Color(string Estanteria, ref bool pasillo)
        {
            if ( Estanteria.Contains("C"))
            { 
                pasillo = false;
                return Color.SkyBlue;

            }
            else if (Estanteria.Contains("F"))
            {
                pasillo = false;
                return Color.Coral;

            }
            else if (Estanteria.Contains("N"))
            {
                pasillo = false;
                return Color.Yellow;
            }
            else if (Estanteria.Contains("O"))
            {
                pasillo = true;
                return Color.White;
            }
           
            else if ( Estanteria.Contains("P"))
            {
                pasillo = true;
                return Color.Gray;
            }

            else
            {
                pasillo = false;
                return Color.Transparent;
            }
           
        }
        //funcion que da nombre a los picturbox que contienen a los robots
        private void Tipo_Robot(string tipo_robot, ref string pic_tipo_robot)
        {
            if (tipo_robot == "R++")
            {
                tipo_robot = "R++" + "_" + cont_rs.ToString();
                cont_rs++;
            }
           
            else if (tipo_robot == "R+-")
            {
                tipo_robot = "R+-" + "_" + cont_rh.ToString();
                cont_rh++;
            }
          
            else if (tipo_robot == "R--")
            {
                tipo_robot = "R--" + "+" + cont_rn.ToString();
                cont_rn++;
            }

            else
            {
                MessageBox.Show("ERROR INGRESO UN ROBOT INVALIDO");
                Application.Exit();
            }
            
        }
        // crea las configuraciones que tendran los picturebox de los robots
        private void Cargar_imagen_Tipo_Robot(string tipo_robot, ref PictureBox pic_tipo_robot, int posx, int posy)
        {
            if (tipo_robot.Contains("R++"))
            {
                pic_tipo_robot.Name = tipo_robot;
                pic_tipo_robot.Location = new Point(posx, posy);
                pic_tipo_robot.Width = 70;
                pic_tipo_robot.Height = 70;
                pic_tipo_robot.Location = new Point(posx, posy);
                pic_tipo_robot.SizeMode = PictureBoxSizeMode.StretchImage;
                pic_tipo_robot.Image = Properties.Resources.robot_1;
                pic_tipo_robot.Visible = true;
                pic_tipo_robot.Enabled = false;
            }
            
            else if (tipo_robot.Contains("R+-"))
            {
                pic_tipo_robot.Name = tipo_robot;
                pic_tipo_robot.Location = new Point(posx, posy);
                pic_tipo_robot.Width = 70;
                pic_tipo_robot.Height = 70;
                pic_tipo_robot.SizeMode = PictureBoxSizeMode.StretchImage;
                pic_tipo_robot.Image = Properties.Resources.robot_3;
                pic_tipo_robot.Visible = true;
                pic_tipo_robot.Enabled = false;
            }
           
            else if (tipo_robot.Contains("R--"))
            {
                pic_tipo_robot.Name = tipo_robot;
                pic_tipo_robot.Width = 70;
                pic_tipo_robot.Height = 70;
                pic_tipo_robot.Location = new Point(posx, posy);
                pic_tipo_robot.SizeMode = PictureBoxSizeMode.StretchImage;
                pic_tipo_robot.Image = Properties.Resources.robot_4;
                pic_tipo_robot.Visible = true;
                pic_tipo_robot.Enabled = false;
            }

            else
            {
                MessageBox.Show("ERROR INGRESO UN ROBOT INVALIDO");
                Application.Exit();
            }
           
        }
       /* private Image CargarImagen(string tipo)
        {
            if (tipo.ToUpper() == "F")
            {
                return ListaImagenesMatriz.Images[0];


            }
            else if (tipo.ToUpper() == "C")
            {
                return ListaImagenesMatriz.Images[1];

            }
            else if (tipo.ToUpper() == "O")
            {
                return ListaImagenesMatriz.Images[7];
            }
            else if (tipo.ToUpper() == "N")
            {
                return ListaImagenesMatriz.Images[2];

            }
            else if (tipo.ToUpper() == "P")
            {
                return ListaImagenesMatriz.Images[6];


            }
            else if (tipo.ToUpper() == "R++")
            {
                return ListaImagenesMatriz.Images[3];


            }
            else if (tipo.ToUpper() == "R+-")
            {
                return ListaImagenesMatriz.Images[4];


            }
            else if (tipo.ToUpper() == "R--")
            {
                return ListaImagenesMatriz.Images[5];


            }
            else
            {
                MessageBox.Show("ERROR INGRESO UN ROBOT INVALIDO");
                Application.Exit();
                return null;
            }

        }
       */
        private void Form1_Load(object sender, EventArgs e)
        {
           
        }

        private void BTNIniciar_Click(object sender, EventArgs e)
        {
            EscogerConfiguracion EC = new EscogerConfiguracion();
            EC.ShowDialog();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            CargarConfiguracion();
        }

    }

}
