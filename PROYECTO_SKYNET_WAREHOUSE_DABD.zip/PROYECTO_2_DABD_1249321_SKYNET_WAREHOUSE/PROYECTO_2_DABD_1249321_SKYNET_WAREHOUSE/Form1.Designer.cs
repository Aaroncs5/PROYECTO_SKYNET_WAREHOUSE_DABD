﻿
namespace PROYECTO_2_DABD_1249321_SKYNET_WAREHOUSE
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.BTNIniciar = new System.Windows.Forms.Button();
            this.BTNReportes = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.logo = new System.Windows.Forms.PictureBox();
            this.Robot1 = new System.Windows.Forms.PictureBox();
            this.Robot2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.PB_0_0 = new System.Windows.Forms.PictureBox();
            this.PB_1_0 = new System.Windows.Forms.PictureBox();
            this.PB_2_0 = new System.Windows.Forms.PictureBox();
            this.PB_3_0 = new System.Windows.Forms.PictureBox();
            this.PB_4_0 = new System.Windows.Forms.PictureBox();
            this.PB_5_0 = new System.Windows.Forms.PictureBox();
            this.PB_6_0 = new System.Windows.Forms.PictureBox();
            this.PB_7_0 = new System.Windows.Forms.PictureBox();
            this.PB_8_0 = new System.Windows.Forms.PictureBox();
            this.PB_9_0 = new System.Windows.Forms.PictureBox();
            this.PB_9_1 = new System.Windows.Forms.PictureBox();
            this.PB_8_1 = new System.Windows.Forms.PictureBox();
            this.PB_7_1 = new System.Windows.Forms.PictureBox();
            this.PB_6_1 = new System.Windows.Forms.PictureBox();
            this.PB_5_1 = new System.Windows.Forms.PictureBox();
            this.PB_4_1 = new System.Windows.Forms.PictureBox();
            this.PB_3_1 = new System.Windows.Forms.PictureBox();
            this.PB_2_1 = new System.Windows.Forms.PictureBox();
            this.PB_1_1 = new System.Windows.Forms.PictureBox();
            this.PB_0_1 = new System.Windows.Forms.PictureBox();
            this.PB_9_2 = new System.Windows.Forms.PictureBox();
            this.PB_8_2 = new System.Windows.Forms.PictureBox();
            this.PB_7_2 = new System.Windows.Forms.PictureBox();
            this.PB_6_2 = new System.Windows.Forms.PictureBox();
            this.PB_5_2 = new System.Windows.Forms.PictureBox();
            this.PB_4_2 = new System.Windows.Forms.PictureBox();
            this.PB_3_2 = new System.Windows.Forms.PictureBox();
            this.PB_2_2 = new System.Windows.Forms.PictureBox();
            this.PB_1_2 = new System.Windows.Forms.PictureBox();
            this.PB_0_2 = new System.Windows.Forms.PictureBox();
            this.PB_9_3 = new System.Windows.Forms.PictureBox();
            this.PB_8_3 = new System.Windows.Forms.PictureBox();
            this.PB_7_3 = new System.Windows.Forms.PictureBox();
            this.PB_6_3 = new System.Windows.Forms.PictureBox();
            this.PB_5_3 = new System.Windows.Forms.PictureBox();
            this.PB_4_3 = new System.Windows.Forms.PictureBox();
            this.PB_3_3 = new System.Windows.Forms.PictureBox();
            this.PB_2_3 = new System.Windows.Forms.PictureBox();
            this.PB_1_3 = new System.Windows.Forms.PictureBox();
            this.PB_0_3 = new System.Windows.Forms.PictureBox();
            this.PB_9_4 = new System.Windows.Forms.PictureBox();
            this.PB_8_4 = new System.Windows.Forms.PictureBox();
            this.PB_7_4 = new System.Windows.Forms.PictureBox();
            this.PB_6_4 = new System.Windows.Forms.PictureBox();
            this.PB_5_4 = new System.Windows.Forms.PictureBox();
            this.PB_4_4 = new System.Windows.Forms.PictureBox();
            this.PB_3_4 = new System.Windows.Forms.PictureBox();
            this.PB_2_4 = new System.Windows.Forms.PictureBox();
            this.PB_1_4 = new System.Windows.Forms.PictureBox();
            this.PB_0_4 = new System.Windows.Forms.PictureBox();
            this.PB_9_5 = new System.Windows.Forms.PictureBox();
            this.PB_8_5 = new System.Windows.Forms.PictureBox();
            this.PB_7_5 = new System.Windows.Forms.PictureBox();
            this.PB_6_5 = new System.Windows.Forms.PictureBox();
            this.PB_5_5 = new System.Windows.Forms.PictureBox();
            this.PB_4_5 = new System.Windows.Forms.PictureBox();
            this.PB_3_5 = new System.Windows.Forms.PictureBox();
            this.PB_2_5 = new System.Windows.Forms.PictureBox();
            this.PB_1_5 = new System.Windows.Forms.PictureBox();
            this.PB_0_5 = new System.Windows.Forms.PictureBox();
            this.PB_9_6 = new System.Windows.Forms.PictureBox();
            this.PB_8_6 = new System.Windows.Forms.PictureBox();
            this.PB_7_6 = new System.Windows.Forms.PictureBox();
            this.PB_6_6 = new System.Windows.Forms.PictureBox();
            this.PB_5_6 = new System.Windows.Forms.PictureBox();
            this.PB_4_6 = new System.Windows.Forms.PictureBox();
            this.PB_3_6 = new System.Windows.Forms.PictureBox();
            this.PB_2_6 = new System.Windows.Forms.PictureBox();
            this.PB_1_6 = new System.Windows.Forms.PictureBox();
            this.PB_0_6 = new System.Windows.Forms.PictureBox();
            this.PB_9_7 = new System.Windows.Forms.PictureBox();
            this.PB_8_7 = new System.Windows.Forms.PictureBox();
            this.PB_7_7 = new System.Windows.Forms.PictureBox();
            this.PB_6_7 = new System.Windows.Forms.PictureBox();
            this.PB_5_7 = new System.Windows.Forms.PictureBox();
            this.PB_4_7 = new System.Windows.Forms.PictureBox();
            this.PB_3_7 = new System.Windows.Forms.PictureBox();
            this.PB_2_7 = new System.Windows.Forms.PictureBox();
            this.PB_1_7 = new System.Windows.Forms.PictureBox();
            this.PB_0_7 = new System.Windows.Forms.PictureBox();
            this.PB_9_8 = new System.Windows.Forms.PictureBox();
            this.PB_8_8 = new System.Windows.Forms.PictureBox();
            this.PB_7_8 = new System.Windows.Forms.PictureBox();
            this.PB_6_8 = new System.Windows.Forms.PictureBox();
            this.PB_5_8 = new System.Windows.Forms.PictureBox();
            this.PB_4_8 = new System.Windows.Forms.PictureBox();
            this.PB_3_8 = new System.Windows.Forms.PictureBox();
            this.PB_2_8 = new System.Windows.Forms.PictureBox();
            this.PB_1_8 = new System.Windows.Forms.PictureBox();
            this.PB_0_8 = new System.Windows.Forms.PictureBox();
            this.PB_9_9 = new System.Windows.Forms.PictureBox();
            this.PB_8_9 = new System.Windows.Forms.PictureBox();
            this.PB_7_9 = new System.Windows.Forms.PictureBox();
            this.PB_6_9 = new System.Windows.Forms.PictureBox();
            this.PB_5_9 = new System.Windows.Forms.PictureBox();
            this.PB_4_9 = new System.Windows.Forms.PictureBox();
            this.PB_3_9 = new System.Windows.Forms.PictureBox();
            this.PB_2_9 = new System.Windows.Forms.PictureBox();
            this.PB_1_9 = new System.Windows.Forms.PictureBox();
            this.PB_0_9 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.logo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Robot1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Robot2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PB_0_0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_1_0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_2_0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_3_0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_4_0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_5_0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_6_0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_7_0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_8_0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_9_0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_9_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_8_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_7_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_6_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_5_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_4_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_3_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_2_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_1_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_0_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_9_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_8_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_7_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_6_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_5_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_4_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_3_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_2_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_1_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_0_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_9_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_8_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_7_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_6_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_5_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_4_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_3_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_2_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_1_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_0_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_9_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_8_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_7_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_6_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_5_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_4_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_3_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_2_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_1_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_0_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_9_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_8_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_7_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_6_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_5_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_4_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_3_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_2_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_1_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_0_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_9_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_8_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_7_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_6_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_5_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_4_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_3_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_2_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_1_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_0_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_9_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_8_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_7_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_6_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_5_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_4_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_3_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_2_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_1_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_0_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_9_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_8_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_7_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_6_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_5_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_4_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_3_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_2_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_1_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_0_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_9_9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_8_9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_7_9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_6_9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_5_9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_4_9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_3_9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_2_9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_1_9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_0_9)).BeginInit();
            this.SuspendLayout();
            // 
            // BTNIniciar
            // 
            this.BTNIniciar.BackColor = System.Drawing.Color.SpringGreen;
            this.BTNIniciar.Font = new System.Drawing.Font("Strong Brain", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNIniciar.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BTNIniciar.Location = new System.Drawing.Point(830, 706);
            this.BTNIniciar.Name = "BTNIniciar";
            this.BTNIniciar.Size = new System.Drawing.Size(224, 63);
            this.BTNIniciar.TabIndex = 103;
            this.BTNIniciar.Text = "¡Iniciar!";
            this.BTNIniciar.UseVisualStyleBackColor = false;
            this.BTNIniciar.Click += new System.EventHandler(this.BTNIniciar_Click);
            // 
            // BTNReportes
            // 
            this.BTNReportes.BackColor = System.Drawing.Color.SpringGreen;
            this.BTNReportes.Font = new System.Drawing.Font("Strong Brain", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNReportes.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BTNReportes.Location = new System.Drawing.Point(1141, 706);
            this.BTNReportes.Name = "BTNReportes";
            this.BTNReportes.Size = new System.Drawing.Size(221, 63);
            this.BTNReportes.TabIndex = 108;
            this.BTNReportes.Text = "REPORTES!";
            this.BTNReportes.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Gold;
            this.label1.Font = new System.Drawing.Font("Impact", 27.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(966, 91);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(224, 45);
            this.label1.TabIndex = 109;
            this.label1.Text = "BIENVENIDO A:";
            // 
            // logo
            // 
            this.logo.BackColor = System.Drawing.Color.Transparent;
            this.logo.BackgroundImage = global::PROYECTO_2_DABD_1249321_SKYNET_WAREHOUSE.Properties.Resources.LOGO_PNG;
            this.logo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.logo.Location = new System.Drawing.Point(444, 72);
            this.logo.Name = "logo";
            this.logo.Size = new System.Drawing.Size(967, 492);
            this.logo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.logo.TabIndex = 111;
            this.logo.TabStop = false;
            // 
            // Robot1
            // 
            this.Robot1.BackColor = System.Drawing.Color.Yellow;
            this.Robot1.Image = global::PROYECTO_2_DABD_1249321_SKYNET_WAREHOUSE.Properties.Resources.robot_1;
            this.Robot1.Location = new System.Drawing.Point(908, 605);
            this.Robot1.Name = "Robot1";
            this.Robot1.Size = new System.Drawing.Size(80, 80);
            this.Robot1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Robot1.TabIndex = 112;
            this.Robot1.TabStop = false;
            // 
            // Robot2
            // 
            this.Robot2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Robot2.Image = ((System.Drawing.Image)(resources.GetObject("Robot2.Image")));
            this.Robot2.Location = new System.Drawing.Point(1063, 605);
            this.Robot2.Name = "Robot2";
            this.Robot2.Size = new System.Drawing.Size(80, 80);
            this.Robot2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Robot2.TabIndex = 113;
            this.Robot2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Gold;
            this.pictureBox1.Image = global::PROYECTO_2_DABD_1249321_SKYNET_WAREHOUSE.Properties.Resources.robot_3;
            this.pictureBox1.Location = new System.Drawing.Point(1213, 605);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(80, 80);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 114;
            this.pictureBox1.TabStop = false;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.SkyBlue;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1390, 34);
            this.menuStrip1.TabIndex = 115;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // menuToolStripMenuItem
            // 
            this.menuToolStripMenuItem.BackColor = System.Drawing.Color.LimeGreen;
            this.menuToolStripMenuItem.Font = new System.Drawing.Font("MS Reference Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuToolStripMenuItem.Name = "menuToolStripMenuItem";
            this.menuToolStripMenuItem.Size = new System.Drawing.Size(313, 30);
            this.menuToolStripMenuItem.Text = "¡INICAR NUEVA BODEGA!";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // PB_0_0
            // 
            this.PB_0_0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_0_0.Enabled = false;
            this.PB_0_0.Location = new System.Drawing.Point(0, 34);
            this.PB_0_0.Name = "PB_0_0";
            this.PB_0_0.Size = new System.Drawing.Size(80, 80);
            this.PB_0_0.TabIndex = 116;
            this.PB_0_0.TabStop = false;
            this.PB_0_0.Visible = false;
            // 
            // PB_1_0
            // 
            this.PB_1_0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_1_0.Enabled = false;
            this.PB_1_0.Location = new System.Drawing.Point(76, 34);
            this.PB_1_0.Name = "PB_1_0";
            this.PB_1_0.Size = new System.Drawing.Size(80, 80);
            this.PB_1_0.TabIndex = 117;
            this.PB_1_0.TabStop = false;
            this.PB_1_0.Visible = false;
            // 
            // PB_2_0
            // 
            this.PB_2_0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_2_0.Enabled = false;
            this.PB_2_0.Location = new System.Drawing.Point(153, 34);
            this.PB_2_0.Name = "PB_2_0";
            this.PB_2_0.Size = new System.Drawing.Size(80, 80);
            this.PB_2_0.TabIndex = 118;
            this.PB_2_0.TabStop = false;
            this.PB_2_0.Visible = false;
            // 
            // PB_3_0
            // 
            this.PB_3_0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_3_0.Enabled = false;
            this.PB_3_0.Location = new System.Drawing.Point(230, 34);
            this.PB_3_0.Name = "PB_3_0";
            this.PB_3_0.Size = new System.Drawing.Size(80, 80);
            this.PB_3_0.TabIndex = 119;
            this.PB_3_0.TabStop = false;
            this.PB_3_0.Visible = false;
            // 
            // PB_4_0
            // 
            this.PB_4_0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_4_0.Enabled = false;
            this.PB_4_0.Location = new System.Drawing.Point(307, 34);
            this.PB_4_0.Name = "PB_4_0";
            this.PB_4_0.Size = new System.Drawing.Size(80, 80);
            this.PB_4_0.TabIndex = 120;
            this.PB_4_0.TabStop = false;
            this.PB_4_0.Visible = false;
            // 
            // PB_5_0
            // 
            this.PB_5_0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_5_0.Enabled = false;
            this.PB_5_0.Location = new System.Drawing.Point(384, 34);
            this.PB_5_0.Name = "PB_5_0";
            this.PB_5_0.Size = new System.Drawing.Size(80, 80);
            this.PB_5_0.TabIndex = 121;
            this.PB_5_0.TabStop = false;
            this.PB_5_0.Visible = false;
            // 
            // PB_6_0
            // 
            this.PB_6_0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_6_0.Enabled = false;
            this.PB_6_0.Location = new System.Drawing.Point(461, 34);
            this.PB_6_0.Name = "PB_6_0";
            this.PB_6_0.Size = new System.Drawing.Size(80, 80);
            this.PB_6_0.TabIndex = 122;
            this.PB_6_0.TabStop = false;
            this.PB_6_0.Visible = false;
            // 
            // PB_7_0
            // 
            this.PB_7_0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_7_0.Enabled = false;
            this.PB_7_0.Location = new System.Drawing.Point(538, 34);
            this.PB_7_0.Name = "PB_7_0";
            this.PB_7_0.Size = new System.Drawing.Size(80, 80);
            this.PB_7_0.TabIndex = 123;
            this.PB_7_0.TabStop = false;
            this.PB_7_0.Visible = false;
            // 
            // PB_8_0
            // 
            this.PB_8_0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_8_0.Enabled = false;
            this.PB_8_0.Location = new System.Drawing.Point(615, 34);
            this.PB_8_0.Name = "PB_8_0";
            this.PB_8_0.Size = new System.Drawing.Size(80, 80);
            this.PB_8_0.TabIndex = 124;
            this.PB_8_0.TabStop = false;
            this.PB_8_0.Visible = false;
            // 
            // PB_9_0
            // 
            this.PB_9_0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_9_0.Enabled = false;
            this.PB_9_0.Location = new System.Drawing.Point(692, 34);
            this.PB_9_0.Name = "PB_9_0";
            this.PB_9_0.Size = new System.Drawing.Size(80, 80);
            this.PB_9_0.TabIndex = 125;
            this.PB_9_0.TabStop = false;
            this.PB_9_0.Visible = false;
            // 
            // PB_9_1
            // 
            this.PB_9_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_9_1.Enabled = false;
            this.PB_9_1.Location = new System.Drawing.Point(692, 111);
            this.PB_9_1.Name = "PB_9_1";
            this.PB_9_1.Size = new System.Drawing.Size(80, 80);
            this.PB_9_1.TabIndex = 135;
            this.PB_9_1.TabStop = false;
            this.PB_9_1.Visible = false;
            // 
            // PB_8_1
            // 
            this.PB_8_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_8_1.Enabled = false;
            this.PB_8_1.Location = new System.Drawing.Point(615, 111);
            this.PB_8_1.Name = "PB_8_1";
            this.PB_8_1.Size = new System.Drawing.Size(80, 80);
            this.PB_8_1.TabIndex = 134;
            this.PB_8_1.TabStop = false;
            this.PB_8_1.Visible = false;
            // 
            // PB_7_1
            // 
            this.PB_7_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_7_1.Enabled = false;
            this.PB_7_1.Location = new System.Drawing.Point(538, 111);
            this.PB_7_1.Name = "PB_7_1";
            this.PB_7_1.Size = new System.Drawing.Size(80, 80);
            this.PB_7_1.TabIndex = 133;
            this.PB_7_1.TabStop = false;
            this.PB_7_1.Visible = false;
            // 
            // PB_6_1
            // 
            this.PB_6_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_6_1.Enabled = false;
            this.PB_6_1.Location = new System.Drawing.Point(461, 111);
            this.PB_6_1.Name = "PB_6_1";
            this.PB_6_1.Size = new System.Drawing.Size(80, 80);
            this.PB_6_1.TabIndex = 132;
            this.PB_6_1.TabStop = false;
            this.PB_6_1.Visible = false;
            // 
            // PB_5_1
            // 
            this.PB_5_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_5_1.Enabled = false;
            this.PB_5_1.Location = new System.Drawing.Point(384, 111);
            this.PB_5_1.Name = "PB_5_1";
            this.PB_5_1.Size = new System.Drawing.Size(80, 80);
            this.PB_5_1.TabIndex = 131;
            this.PB_5_1.TabStop = false;
            this.PB_5_1.Visible = false;
            // 
            // PB_4_1
            // 
            this.PB_4_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_4_1.Enabled = false;
            this.PB_4_1.Location = new System.Drawing.Point(307, 111);
            this.PB_4_1.Name = "PB_4_1";
            this.PB_4_1.Size = new System.Drawing.Size(80, 80);
            this.PB_4_1.TabIndex = 130;
            this.PB_4_1.TabStop = false;
            this.PB_4_1.Visible = false;
            // 
            // PB_3_1
            // 
            this.PB_3_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_3_1.Enabled = false;
            this.PB_3_1.Location = new System.Drawing.Point(230, 111);
            this.PB_3_1.Name = "PB_3_1";
            this.PB_3_1.Size = new System.Drawing.Size(80, 80);
            this.PB_3_1.TabIndex = 129;
            this.PB_3_1.TabStop = false;
            this.PB_3_1.Visible = false;
            // 
            // PB_2_1
            // 
            this.PB_2_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_2_1.Enabled = false;
            this.PB_2_1.Location = new System.Drawing.Point(153, 111);
            this.PB_2_1.Name = "PB_2_1";
            this.PB_2_1.Size = new System.Drawing.Size(80, 80);
            this.PB_2_1.TabIndex = 128;
            this.PB_2_1.TabStop = false;
            this.PB_2_1.Visible = false;
            // 
            // PB_1_1
            // 
            this.PB_1_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_1_1.Enabled = false;
            this.PB_1_1.Location = new System.Drawing.Point(76, 111);
            this.PB_1_1.Name = "PB_1_1";
            this.PB_1_1.Size = new System.Drawing.Size(80, 80);
            this.PB_1_1.TabIndex = 127;
            this.PB_1_1.TabStop = false;
            this.PB_1_1.Visible = false;
            // 
            // PB_0_1
            // 
            this.PB_0_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_0_1.Enabled = false;
            this.PB_0_1.Location = new System.Drawing.Point(0, 111);
            this.PB_0_1.Name = "PB_0_1";
            this.PB_0_1.Size = new System.Drawing.Size(80, 80);
            this.PB_0_1.TabIndex = 126;
            this.PB_0_1.TabStop = false;
            this.PB_0_1.Visible = false;
            // 
            // PB_9_2
            // 
            this.PB_9_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_9_2.Enabled = false;
            this.PB_9_2.Location = new System.Drawing.Point(692, 188);
            this.PB_9_2.Name = "PB_9_2";
            this.PB_9_2.Size = new System.Drawing.Size(80, 80);
            this.PB_9_2.TabIndex = 145;
            this.PB_9_2.TabStop = false;
            this.PB_9_2.Visible = false;
            // 
            // PB_8_2
            // 
            this.PB_8_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_8_2.Enabled = false;
            this.PB_8_2.Location = new System.Drawing.Point(615, 188);
            this.PB_8_2.Name = "PB_8_2";
            this.PB_8_2.Size = new System.Drawing.Size(80, 80);
            this.PB_8_2.TabIndex = 144;
            this.PB_8_2.TabStop = false;
            this.PB_8_2.Visible = false;
            // 
            // PB_7_2
            // 
            this.PB_7_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_7_2.Enabled = false;
            this.PB_7_2.Location = new System.Drawing.Point(538, 188);
            this.PB_7_2.Name = "PB_7_2";
            this.PB_7_2.Size = new System.Drawing.Size(80, 80);
            this.PB_7_2.TabIndex = 143;
            this.PB_7_2.TabStop = false;
            this.PB_7_2.Visible = false;
            // 
            // PB_6_2
            // 
            this.PB_6_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_6_2.Enabled = false;
            this.PB_6_2.Location = new System.Drawing.Point(461, 188);
            this.PB_6_2.Name = "PB_6_2";
            this.PB_6_2.Size = new System.Drawing.Size(80, 80);
            this.PB_6_2.TabIndex = 142;
            this.PB_6_2.TabStop = false;
            this.PB_6_2.Visible = false;
            // 
            // PB_5_2
            // 
            this.PB_5_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_5_2.Enabled = false;
            this.PB_5_2.Location = new System.Drawing.Point(384, 188);
            this.PB_5_2.Name = "PB_5_2";
            this.PB_5_2.Size = new System.Drawing.Size(80, 80);
            this.PB_5_2.TabIndex = 141;
            this.PB_5_2.TabStop = false;
            this.PB_5_2.Visible = false;
            // 
            // PB_4_2
            // 
            this.PB_4_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_4_2.Enabled = false;
            this.PB_4_2.Location = new System.Drawing.Point(307, 188);
            this.PB_4_2.Name = "PB_4_2";
            this.PB_4_2.Size = new System.Drawing.Size(80, 80);
            this.PB_4_2.TabIndex = 140;
            this.PB_4_2.TabStop = false;
            this.PB_4_2.Visible = false;
            // 
            // PB_3_2
            // 
            this.PB_3_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_3_2.Enabled = false;
            this.PB_3_2.Location = new System.Drawing.Point(230, 188);
            this.PB_3_2.Name = "PB_3_2";
            this.PB_3_2.Size = new System.Drawing.Size(80, 80);
            this.PB_3_2.TabIndex = 139;
            this.PB_3_2.TabStop = false;
            this.PB_3_2.Visible = false;
            // 
            // PB_2_2
            // 
            this.PB_2_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_2_2.Enabled = false;
            this.PB_2_2.Location = new System.Drawing.Point(153, 188);
            this.PB_2_2.Name = "PB_2_2";
            this.PB_2_2.Size = new System.Drawing.Size(80, 80);
            this.PB_2_2.TabIndex = 138;
            this.PB_2_2.TabStop = false;
            this.PB_2_2.Visible = false;
            // 
            // PB_1_2
            // 
            this.PB_1_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_1_2.Enabled = false;
            this.PB_1_2.Location = new System.Drawing.Point(76, 188);
            this.PB_1_2.Name = "PB_1_2";
            this.PB_1_2.Size = new System.Drawing.Size(80, 80);
            this.PB_1_2.TabIndex = 137;
            this.PB_1_2.TabStop = false;
            this.PB_1_2.Visible = false;
            // 
            // PB_0_2
            // 
            this.PB_0_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_0_2.Enabled = false;
            this.PB_0_2.Location = new System.Drawing.Point(0, 188);
            this.PB_0_2.Name = "PB_0_2";
            this.PB_0_2.Size = new System.Drawing.Size(80, 80);
            this.PB_0_2.TabIndex = 136;
            this.PB_0_2.TabStop = false;
            this.PB_0_2.Visible = false;
            // 
            // PB_9_3
            // 
            this.PB_9_3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_9_3.Enabled = false;
            this.PB_9_3.Location = new System.Drawing.Point(692, 265);
            this.PB_9_3.Name = "PB_9_3";
            this.PB_9_3.Size = new System.Drawing.Size(80, 80);
            this.PB_9_3.TabIndex = 155;
            this.PB_9_3.TabStop = false;
            this.PB_9_3.Visible = false;
            // 
            // PB_8_3
            // 
            this.PB_8_3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_8_3.Enabled = false;
            this.PB_8_3.Location = new System.Drawing.Point(615, 265);
            this.PB_8_3.Name = "PB_8_3";
            this.PB_8_3.Size = new System.Drawing.Size(80, 80);
            this.PB_8_3.TabIndex = 154;
            this.PB_8_3.TabStop = false;
            this.PB_8_3.Visible = false;
            // 
            // PB_7_3
            // 
            this.PB_7_3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_7_3.Enabled = false;
            this.PB_7_3.Location = new System.Drawing.Point(538, 265);
            this.PB_7_3.Name = "PB_7_3";
            this.PB_7_3.Size = new System.Drawing.Size(80, 80);
            this.PB_7_3.TabIndex = 153;
            this.PB_7_3.TabStop = false;
            this.PB_7_3.Visible = false;
            // 
            // PB_6_3
            // 
            this.PB_6_3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_6_3.Enabled = false;
            this.PB_6_3.Location = new System.Drawing.Point(461, 265);
            this.PB_6_3.Name = "PB_6_3";
            this.PB_6_3.Size = new System.Drawing.Size(80, 80);
            this.PB_6_3.TabIndex = 152;
            this.PB_6_3.TabStop = false;
            this.PB_6_3.Visible = false;
            // 
            // PB_5_3
            // 
            this.PB_5_3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_5_3.Enabled = false;
            this.PB_5_3.Location = new System.Drawing.Point(384, 265);
            this.PB_5_3.Name = "PB_5_3";
            this.PB_5_3.Size = new System.Drawing.Size(80, 80);
            this.PB_5_3.TabIndex = 151;
            this.PB_5_3.TabStop = false;
            this.PB_5_3.Visible = false;
            // 
            // PB_4_3
            // 
            this.PB_4_3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_4_3.Enabled = false;
            this.PB_4_3.Location = new System.Drawing.Point(307, 265);
            this.PB_4_3.Name = "PB_4_3";
            this.PB_4_3.Size = new System.Drawing.Size(80, 80);
            this.PB_4_3.TabIndex = 150;
            this.PB_4_3.TabStop = false;
            this.PB_4_3.Visible = false;
            // 
            // PB_3_3
            // 
            this.PB_3_3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_3_3.Enabled = false;
            this.PB_3_3.Location = new System.Drawing.Point(230, 265);
            this.PB_3_3.Name = "PB_3_3";
            this.PB_3_3.Size = new System.Drawing.Size(80, 80);
            this.PB_3_3.TabIndex = 149;
            this.PB_3_3.TabStop = false;
            this.PB_3_3.Visible = false;
            // 
            // PB_2_3
            // 
            this.PB_2_3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_2_3.Enabled = false;
            this.PB_2_3.Location = new System.Drawing.Point(153, 265);
            this.PB_2_3.Name = "PB_2_3";
            this.PB_2_3.Size = new System.Drawing.Size(80, 80);
            this.PB_2_3.TabIndex = 148;
            this.PB_2_3.TabStop = false;
            this.PB_2_3.Visible = false;
            // 
            // PB_1_3
            // 
            this.PB_1_3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_1_3.Enabled = false;
            this.PB_1_3.Location = new System.Drawing.Point(76, 265);
            this.PB_1_3.Name = "PB_1_3";
            this.PB_1_3.Size = new System.Drawing.Size(80, 80);
            this.PB_1_3.TabIndex = 147;
            this.PB_1_3.TabStop = false;
            this.PB_1_3.Visible = false;
            // 
            // PB_0_3
            // 
            this.PB_0_3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_0_3.Enabled = false;
            this.PB_0_3.Location = new System.Drawing.Point(0, 265);
            this.PB_0_3.Name = "PB_0_3";
            this.PB_0_3.Size = new System.Drawing.Size(80, 80);
            this.PB_0_3.TabIndex = 146;
            this.PB_0_3.TabStop = false;
            this.PB_0_3.Visible = false;
            // 
            // PB_9_4
            // 
            this.PB_9_4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_9_4.Enabled = false;
            this.PB_9_4.Location = new System.Drawing.Point(692, 341);
            this.PB_9_4.Name = "PB_9_4";
            this.PB_9_4.Size = new System.Drawing.Size(80, 80);
            this.PB_9_4.TabIndex = 165;
            this.PB_9_4.TabStop = false;
            this.PB_9_4.Visible = false;
            // 
            // PB_8_4
            // 
            this.PB_8_4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_8_4.Enabled = false;
            this.PB_8_4.Location = new System.Drawing.Point(615, 341);
            this.PB_8_4.Name = "PB_8_4";
            this.PB_8_4.Size = new System.Drawing.Size(80, 80);
            this.PB_8_4.TabIndex = 164;
            this.PB_8_4.TabStop = false;
            this.PB_8_4.Visible = false;
            // 
            // PB_7_4
            // 
            this.PB_7_4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_7_4.Enabled = false;
            this.PB_7_4.Location = new System.Drawing.Point(538, 341);
            this.PB_7_4.Name = "PB_7_4";
            this.PB_7_4.Size = new System.Drawing.Size(80, 80);
            this.PB_7_4.TabIndex = 163;
            this.PB_7_4.TabStop = false;
            this.PB_7_4.Visible = false;
            // 
            // PB_6_4
            // 
            this.PB_6_4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_6_4.Enabled = false;
            this.PB_6_4.Location = new System.Drawing.Point(461, 341);
            this.PB_6_4.Name = "PB_6_4";
            this.PB_6_4.Size = new System.Drawing.Size(80, 80);
            this.PB_6_4.TabIndex = 162;
            this.PB_6_4.TabStop = false;
            this.PB_6_4.Visible = false;
            // 
            // PB_5_4
            // 
            this.PB_5_4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_5_4.Enabled = false;
            this.PB_5_4.Location = new System.Drawing.Point(384, 341);
            this.PB_5_4.Name = "PB_5_4";
            this.PB_5_4.Size = new System.Drawing.Size(80, 80);
            this.PB_5_4.TabIndex = 161;
            this.PB_5_4.TabStop = false;
            this.PB_5_4.Visible = false;
            // 
            // PB_4_4
            // 
            this.PB_4_4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_4_4.Enabled = false;
            this.PB_4_4.Location = new System.Drawing.Point(307, 341);
            this.PB_4_4.Name = "PB_4_4";
            this.PB_4_4.Size = new System.Drawing.Size(80, 80);
            this.PB_4_4.TabIndex = 160;
            this.PB_4_4.TabStop = false;
            this.PB_4_4.Visible = false;
            // 
            // PB_3_4
            // 
            this.PB_3_4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_3_4.Enabled = false;
            this.PB_3_4.Location = new System.Drawing.Point(230, 341);
            this.PB_3_4.Name = "PB_3_4";
            this.PB_3_4.Size = new System.Drawing.Size(80, 80);
            this.PB_3_4.TabIndex = 159;
            this.PB_3_4.TabStop = false;
            this.PB_3_4.Visible = false;
            // 
            // PB_2_4
            // 
            this.PB_2_4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_2_4.Enabled = false;
            this.PB_2_4.Location = new System.Drawing.Point(153, 341);
            this.PB_2_4.Name = "PB_2_4";
            this.PB_2_4.Size = new System.Drawing.Size(80, 80);
            this.PB_2_4.TabIndex = 158;
            this.PB_2_4.TabStop = false;
            this.PB_2_4.Visible = false;
            // 
            // PB_1_4
            // 
            this.PB_1_4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_1_4.Enabled = false;
            this.PB_1_4.Location = new System.Drawing.Point(76, 341);
            this.PB_1_4.Name = "PB_1_4";
            this.PB_1_4.Size = new System.Drawing.Size(80, 80);
            this.PB_1_4.TabIndex = 157;
            this.PB_1_4.TabStop = false;
            this.PB_1_4.Visible = false;
            // 
            // PB_0_4
            // 
            this.PB_0_4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_0_4.Enabled = false;
            this.PB_0_4.Location = new System.Drawing.Point(0, 341);
            this.PB_0_4.Name = "PB_0_4";
            this.PB_0_4.Size = new System.Drawing.Size(80, 80);
            this.PB_0_4.TabIndex = 156;
            this.PB_0_4.TabStop = false;
            this.PB_0_4.Visible = false;
            // 
            // PB_9_5
            // 
            this.PB_9_5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_9_5.Enabled = false;
            this.PB_9_5.Location = new System.Drawing.Point(692, 418);
            this.PB_9_5.Name = "PB_9_5";
            this.PB_9_5.Size = new System.Drawing.Size(80, 80);
            this.PB_9_5.TabIndex = 175;
            this.PB_9_5.TabStop = false;
            this.PB_9_5.Visible = false;
            // 
            // PB_8_5
            // 
            this.PB_8_5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_8_5.Enabled = false;
            this.PB_8_5.Location = new System.Drawing.Point(615, 418);
            this.PB_8_5.Name = "PB_8_5";
            this.PB_8_5.Size = new System.Drawing.Size(80, 80);
            this.PB_8_5.TabIndex = 174;
            this.PB_8_5.TabStop = false;
            this.PB_8_5.Visible = false;
            // 
            // PB_7_5
            // 
            this.PB_7_5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_7_5.Enabled = false;
            this.PB_7_5.Location = new System.Drawing.Point(538, 418);
            this.PB_7_5.Name = "PB_7_5";
            this.PB_7_5.Size = new System.Drawing.Size(80, 80);
            this.PB_7_5.TabIndex = 173;
            this.PB_7_5.TabStop = false;
            this.PB_7_5.Visible = false;
            // 
            // PB_6_5
            // 
            this.PB_6_5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_6_5.Enabled = false;
            this.PB_6_5.Location = new System.Drawing.Point(461, 418);
            this.PB_6_5.Name = "PB_6_5";
            this.PB_6_5.Size = new System.Drawing.Size(80, 80);
            this.PB_6_5.TabIndex = 172;
            this.PB_6_5.TabStop = false;
            this.PB_6_5.Visible = false;
            // 
            // PB_5_5
            // 
            this.PB_5_5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_5_5.Enabled = false;
            this.PB_5_5.Location = new System.Drawing.Point(384, 418);
            this.PB_5_5.Name = "PB_5_5";
            this.PB_5_5.Size = new System.Drawing.Size(80, 80);
            this.PB_5_5.TabIndex = 171;
            this.PB_5_5.TabStop = false;
            this.PB_5_5.Visible = false;
            // 
            // PB_4_5
            // 
            this.PB_4_5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_4_5.Enabled = false;
            this.PB_4_5.Location = new System.Drawing.Point(307, 418);
            this.PB_4_5.Name = "PB_4_5";
            this.PB_4_5.Size = new System.Drawing.Size(80, 80);
            this.PB_4_5.TabIndex = 170;
            this.PB_4_5.TabStop = false;
            this.PB_4_5.Visible = false;
            // 
            // PB_3_5
            // 
            this.PB_3_5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_3_5.Enabled = false;
            this.PB_3_5.Location = new System.Drawing.Point(230, 418);
            this.PB_3_5.Name = "PB_3_5";
            this.PB_3_5.Size = new System.Drawing.Size(80, 80);
            this.PB_3_5.TabIndex = 169;
            this.PB_3_5.TabStop = false;
            this.PB_3_5.Visible = false;
            // 
            // PB_2_5
            // 
            this.PB_2_5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_2_5.Enabled = false;
            this.PB_2_5.Location = new System.Drawing.Point(153, 418);
            this.PB_2_5.Name = "PB_2_5";
            this.PB_2_5.Size = new System.Drawing.Size(80, 80);
            this.PB_2_5.TabIndex = 168;
            this.PB_2_5.TabStop = false;
            this.PB_2_5.Visible = false;
            // 
            // PB_1_5
            // 
            this.PB_1_5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_1_5.Enabled = false;
            this.PB_1_5.Location = new System.Drawing.Point(76, 418);
            this.PB_1_5.Name = "PB_1_5";
            this.PB_1_5.Size = new System.Drawing.Size(80, 80);
            this.PB_1_5.TabIndex = 167;
            this.PB_1_5.TabStop = false;
            this.PB_1_5.Visible = false;
            // 
            // PB_0_5
            // 
            this.PB_0_5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_0_5.Enabled = false;
            this.PB_0_5.Location = new System.Drawing.Point(0, 418);
            this.PB_0_5.Name = "PB_0_5";
            this.PB_0_5.Size = new System.Drawing.Size(80, 80);
            this.PB_0_5.TabIndex = 166;
            this.PB_0_5.TabStop = false;
            this.PB_0_5.Visible = false;
            // 
            // PB_9_6
            // 
            this.PB_9_6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_9_6.Enabled = false;
            this.PB_9_6.Location = new System.Drawing.Point(692, 495);
            this.PB_9_6.Name = "PB_9_6";
            this.PB_9_6.Size = new System.Drawing.Size(80, 80);
            this.PB_9_6.TabIndex = 185;
            this.PB_9_6.TabStop = false;
            this.PB_9_6.Visible = false;
            // 
            // PB_8_6
            // 
            this.PB_8_6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_8_6.Enabled = false;
            this.PB_8_6.Location = new System.Drawing.Point(615, 495);
            this.PB_8_6.Name = "PB_8_6";
            this.PB_8_6.Size = new System.Drawing.Size(80, 80);
            this.PB_8_6.TabIndex = 184;
            this.PB_8_6.TabStop = false;
            this.PB_8_6.Visible = false;
            // 
            // PB_7_6
            // 
            this.PB_7_6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_7_6.Enabled = false;
            this.PB_7_6.Location = new System.Drawing.Point(538, 495);
            this.PB_7_6.Name = "PB_7_6";
            this.PB_7_6.Size = new System.Drawing.Size(80, 80);
            this.PB_7_6.TabIndex = 183;
            this.PB_7_6.TabStop = false;
            this.PB_7_6.Visible = false;
            // 
            // PB_6_6
            // 
            this.PB_6_6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_6_6.Enabled = false;
            this.PB_6_6.Location = new System.Drawing.Point(461, 495);
            this.PB_6_6.Name = "PB_6_6";
            this.PB_6_6.Size = new System.Drawing.Size(80, 80);
            this.PB_6_6.TabIndex = 182;
            this.PB_6_6.TabStop = false;
            this.PB_6_6.Visible = false;
            // 
            // PB_5_6
            // 
            this.PB_5_6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_5_6.Enabled = false;
            this.PB_5_6.Location = new System.Drawing.Point(384, 495);
            this.PB_5_6.Name = "PB_5_6";
            this.PB_5_6.Size = new System.Drawing.Size(80, 80);
            this.PB_5_6.TabIndex = 181;
            this.PB_5_6.TabStop = false;
            this.PB_5_6.Visible = false;
            // 
            // PB_4_6
            // 
            this.PB_4_6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_4_6.Enabled = false;
            this.PB_4_6.Location = new System.Drawing.Point(307, 495);
            this.PB_4_6.Name = "PB_4_6";
            this.PB_4_6.Size = new System.Drawing.Size(80, 80);
            this.PB_4_6.TabIndex = 180;
            this.PB_4_6.TabStop = false;
            this.PB_4_6.Visible = false;
            // 
            // PB_3_6
            // 
            this.PB_3_6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_3_6.Enabled = false;
            this.PB_3_6.Location = new System.Drawing.Point(230, 495);
            this.PB_3_6.Name = "PB_3_6";
            this.PB_3_6.Size = new System.Drawing.Size(80, 80);
            this.PB_3_6.TabIndex = 179;
            this.PB_3_6.TabStop = false;
            this.PB_3_6.Visible = false;
            // 
            // PB_2_6
            // 
            this.PB_2_6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_2_6.Enabled = false;
            this.PB_2_6.Location = new System.Drawing.Point(153, 495);
            this.PB_2_6.Name = "PB_2_6";
            this.PB_2_6.Size = new System.Drawing.Size(80, 80);
            this.PB_2_6.TabIndex = 178;
            this.PB_2_6.TabStop = false;
            this.PB_2_6.Visible = false;
            // 
            // PB_1_6
            // 
            this.PB_1_6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_1_6.Enabled = false;
            this.PB_1_6.Location = new System.Drawing.Point(76, 495);
            this.PB_1_6.Name = "PB_1_6";
            this.PB_1_6.Size = new System.Drawing.Size(80, 80);
            this.PB_1_6.TabIndex = 177;
            this.PB_1_6.TabStop = false;
            this.PB_1_6.Visible = false;
            // 
            // PB_0_6
            // 
            this.PB_0_6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_0_6.Enabled = false;
            this.PB_0_6.Location = new System.Drawing.Point(0, 495);
            this.PB_0_6.Name = "PB_0_6";
            this.PB_0_6.Size = new System.Drawing.Size(80, 80);
            this.PB_0_6.TabIndex = 176;
            this.PB_0_6.TabStop = false;
            this.PB_0_6.Visible = false;
            // 
            // PB_9_7
            // 
            this.PB_9_7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_9_7.Enabled = false;
            this.PB_9_7.Location = new System.Drawing.Point(692, 570);
            this.PB_9_7.Name = "PB_9_7";
            this.PB_9_7.Size = new System.Drawing.Size(80, 80);
            this.PB_9_7.TabIndex = 195;
            this.PB_9_7.TabStop = false;
            this.PB_9_7.Visible = false;
            // 
            // PB_8_7
            // 
            this.PB_8_7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_8_7.Enabled = false;
            this.PB_8_7.Location = new System.Drawing.Point(615, 570);
            this.PB_8_7.Name = "PB_8_7";
            this.PB_8_7.Size = new System.Drawing.Size(80, 80);
            this.PB_8_7.TabIndex = 194;
            this.PB_8_7.TabStop = false;
            this.PB_8_7.Visible = false;
            // 
            // PB_7_7
            // 
            this.PB_7_7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_7_7.Enabled = false;
            this.PB_7_7.Location = new System.Drawing.Point(538, 570);
            this.PB_7_7.Name = "PB_7_7";
            this.PB_7_7.Size = new System.Drawing.Size(80, 80);
            this.PB_7_7.TabIndex = 193;
            this.PB_7_7.TabStop = false;
            this.PB_7_7.Visible = false;
            // 
            // PB_6_7
            // 
            this.PB_6_7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_6_7.Enabled = false;
            this.PB_6_7.Location = new System.Drawing.Point(461, 570);
            this.PB_6_7.Name = "PB_6_7";
            this.PB_6_7.Size = new System.Drawing.Size(80, 80);
            this.PB_6_7.TabIndex = 192;
            this.PB_6_7.TabStop = false;
            this.PB_6_7.Visible = false;
            // 
            // PB_5_7
            // 
            this.PB_5_7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_5_7.Enabled = false;
            this.PB_5_7.Location = new System.Drawing.Point(384, 570);
            this.PB_5_7.Name = "PB_5_7";
            this.PB_5_7.Size = new System.Drawing.Size(80, 80);
            this.PB_5_7.TabIndex = 191;
            this.PB_5_7.TabStop = false;
            this.PB_5_7.Visible = false;
            // 
            // PB_4_7
            // 
            this.PB_4_7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_4_7.Enabled = false;
            this.PB_4_7.Location = new System.Drawing.Point(307, 570);
            this.PB_4_7.Name = "PB_4_7";
            this.PB_4_7.Size = new System.Drawing.Size(80, 80);
            this.PB_4_7.TabIndex = 190;
            this.PB_4_7.TabStop = false;
            this.PB_4_7.Visible = false;
            // 
            // PB_3_7
            // 
            this.PB_3_7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_3_7.Enabled = false;
            this.PB_3_7.Location = new System.Drawing.Point(230, 570);
            this.PB_3_7.Name = "PB_3_7";
            this.PB_3_7.Size = new System.Drawing.Size(80, 80);
            this.PB_3_7.TabIndex = 189;
            this.PB_3_7.TabStop = false;
            this.PB_3_7.Visible = false;
            // 
            // PB_2_7
            // 
            this.PB_2_7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_2_7.Enabled = false;
            this.PB_2_7.Location = new System.Drawing.Point(153, 570);
            this.PB_2_7.Name = "PB_2_7";
            this.PB_2_7.Size = new System.Drawing.Size(80, 80);
            this.PB_2_7.TabIndex = 188;
            this.PB_2_7.TabStop = false;
            this.PB_2_7.Visible = false;
            // 
            // PB_1_7
            // 
            this.PB_1_7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_1_7.Enabled = false;
            this.PB_1_7.Location = new System.Drawing.Point(76, 570);
            this.PB_1_7.Name = "PB_1_7";
            this.PB_1_7.Size = new System.Drawing.Size(80, 80);
            this.PB_1_7.TabIndex = 187;
            this.PB_1_7.TabStop = false;
            this.PB_1_7.Visible = false;
            // 
            // PB_0_7
            // 
            this.PB_0_7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_0_7.Enabled = false;
            this.PB_0_7.Location = new System.Drawing.Point(0, 570);
            this.PB_0_7.Name = "PB_0_7";
            this.PB_0_7.Size = new System.Drawing.Size(80, 80);
            this.PB_0_7.TabIndex = 186;
            this.PB_0_7.TabStop = false;
            this.PB_0_7.Visible = false;
            // 
            // PB_9_8
            // 
            this.PB_9_8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_9_8.Enabled = false;
            this.PB_9_8.Location = new System.Drawing.Point(692, 647);
            this.PB_9_8.Name = "PB_9_8";
            this.PB_9_8.Size = new System.Drawing.Size(80, 80);
            this.PB_9_8.TabIndex = 205;
            this.PB_9_8.TabStop = false;
            this.PB_9_8.Visible = false;
            // 
            // PB_8_8
            // 
            this.PB_8_8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_8_8.Enabled = false;
            this.PB_8_8.Location = new System.Drawing.Point(615, 647);
            this.PB_8_8.Name = "PB_8_8";
            this.PB_8_8.Size = new System.Drawing.Size(80, 80);
            this.PB_8_8.TabIndex = 204;
            this.PB_8_8.TabStop = false;
            this.PB_8_8.Visible = false;
            // 
            // PB_7_8
            // 
            this.PB_7_8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_7_8.Enabled = false;
            this.PB_7_8.Location = new System.Drawing.Point(538, 647);
            this.PB_7_8.Name = "PB_7_8";
            this.PB_7_8.Size = new System.Drawing.Size(80, 80);
            this.PB_7_8.TabIndex = 203;
            this.PB_7_8.TabStop = false;
            this.PB_7_8.Visible = false;
            // 
            // PB_6_8
            // 
            this.PB_6_8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_6_8.Enabled = false;
            this.PB_6_8.Location = new System.Drawing.Point(461, 647);
            this.PB_6_8.Name = "PB_6_8";
            this.PB_6_8.Size = new System.Drawing.Size(80, 80);
            this.PB_6_8.TabIndex = 202;
            this.PB_6_8.TabStop = false;
            this.PB_6_8.Visible = false;
            // 
            // PB_5_8
            // 
            this.PB_5_8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_5_8.Enabled = false;
            this.PB_5_8.Location = new System.Drawing.Point(384, 647);
            this.PB_5_8.Name = "PB_5_8";
            this.PB_5_8.Size = new System.Drawing.Size(80, 80);
            this.PB_5_8.TabIndex = 201;
            this.PB_5_8.TabStop = false;
            this.PB_5_8.Visible = false;
            // 
            // PB_4_8
            // 
            this.PB_4_8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_4_8.Enabled = false;
            this.PB_4_8.Location = new System.Drawing.Point(307, 647);
            this.PB_4_8.Name = "PB_4_8";
            this.PB_4_8.Size = new System.Drawing.Size(80, 80);
            this.PB_4_8.TabIndex = 200;
            this.PB_4_8.TabStop = false;
            this.PB_4_8.Visible = false;
            // 
            // PB_3_8
            // 
            this.PB_3_8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_3_8.Enabled = false;
            this.PB_3_8.Location = new System.Drawing.Point(230, 647);
            this.PB_3_8.Name = "PB_3_8";
            this.PB_3_8.Size = new System.Drawing.Size(80, 80);
            this.PB_3_8.TabIndex = 199;
            this.PB_3_8.TabStop = false;
            this.PB_3_8.Visible = false;
            // 
            // PB_2_8
            // 
            this.PB_2_8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_2_8.Enabled = false;
            this.PB_2_8.Location = new System.Drawing.Point(153, 647);
            this.PB_2_8.Name = "PB_2_8";
            this.PB_2_8.Size = new System.Drawing.Size(80, 80);
            this.PB_2_8.TabIndex = 198;
            this.PB_2_8.TabStop = false;
            this.PB_2_8.Visible = false;
            // 
            // PB_1_8
            // 
            this.PB_1_8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_1_8.Enabled = false;
            this.PB_1_8.Location = new System.Drawing.Point(76, 647);
            this.PB_1_8.Name = "PB_1_8";
            this.PB_1_8.Size = new System.Drawing.Size(80, 80);
            this.PB_1_8.TabIndex = 197;
            this.PB_1_8.TabStop = false;
            this.PB_1_8.Visible = false;
            // 
            // PB_0_8
            // 
            this.PB_0_8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_0_8.Enabled = false;
            this.PB_0_8.Location = new System.Drawing.Point(0, 647);
            this.PB_0_8.Name = "PB_0_8";
            this.PB_0_8.Size = new System.Drawing.Size(80, 80);
            this.PB_0_8.TabIndex = 196;
            this.PB_0_8.TabStop = false;
            this.PB_0_8.Visible = false;
            // 
            // PB_9_9
            // 
            this.PB_9_9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_9_9.Enabled = false;
            this.PB_9_9.Location = new System.Drawing.Point(692, 724);
            this.PB_9_9.Name = "PB_9_9";
            this.PB_9_9.Size = new System.Drawing.Size(80, 80);
            this.PB_9_9.TabIndex = 215;
            this.PB_9_9.TabStop = false;
            this.PB_9_9.Visible = false;
            // 
            // PB_8_9
            // 
            this.PB_8_9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_8_9.Enabled = false;
            this.PB_8_9.Location = new System.Drawing.Point(615, 724);
            this.PB_8_9.Name = "PB_8_9";
            this.PB_8_9.Size = new System.Drawing.Size(80, 80);
            this.PB_8_9.TabIndex = 214;
            this.PB_8_9.TabStop = false;
            this.PB_8_9.Visible = false;
            // 
            // PB_7_9
            // 
            this.PB_7_9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_7_9.Enabled = false;
            this.PB_7_9.Location = new System.Drawing.Point(538, 724);
            this.PB_7_9.Name = "PB_7_9";
            this.PB_7_9.Size = new System.Drawing.Size(80, 80);
            this.PB_7_9.TabIndex = 213;
            this.PB_7_9.TabStop = false;
            this.PB_7_9.Visible = false;
            // 
            // PB_6_9
            // 
            this.PB_6_9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_6_9.Enabled = false;
            this.PB_6_9.Location = new System.Drawing.Point(461, 724);
            this.PB_6_9.Name = "PB_6_9";
            this.PB_6_9.Size = new System.Drawing.Size(80, 80);
            this.PB_6_9.TabIndex = 212;
            this.PB_6_9.TabStop = false;
            this.PB_6_9.Visible = false;
            // 
            // PB_5_9
            // 
            this.PB_5_9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_5_9.Enabled = false;
            this.PB_5_9.Location = new System.Drawing.Point(384, 724);
            this.PB_5_9.Name = "PB_5_9";
            this.PB_5_9.Size = new System.Drawing.Size(80, 80);
            this.PB_5_9.TabIndex = 211;
            this.PB_5_9.TabStop = false;
            this.PB_5_9.Visible = false;
            // 
            // PB_4_9
            // 
            this.PB_4_9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_4_9.Enabled = false;
            this.PB_4_9.Location = new System.Drawing.Point(307, 724);
            this.PB_4_9.Name = "PB_4_9";
            this.PB_4_9.Size = new System.Drawing.Size(80, 80);
            this.PB_4_9.TabIndex = 210;
            this.PB_4_9.TabStop = false;
            this.PB_4_9.Visible = false;
            // 
            // PB_3_9
            // 
            this.PB_3_9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_3_9.Enabled = false;
            this.PB_3_9.Location = new System.Drawing.Point(230, 724);
            this.PB_3_9.Name = "PB_3_9";
            this.PB_3_9.Size = new System.Drawing.Size(80, 80);
            this.PB_3_9.TabIndex = 209;
            this.PB_3_9.TabStop = false;
            this.PB_3_9.Visible = false;
            // 
            // PB_2_9
            // 
            this.PB_2_9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_2_9.Enabled = false;
            this.PB_2_9.Location = new System.Drawing.Point(153, 724);
            this.PB_2_9.Name = "PB_2_9";
            this.PB_2_9.Size = new System.Drawing.Size(80, 80);
            this.PB_2_9.TabIndex = 208;
            this.PB_2_9.TabStop = false;
            this.PB_2_9.Visible = false;
            // 
            // PB_1_9
            // 
            this.PB_1_9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_1_9.Enabled = false;
            this.PB_1_9.Location = new System.Drawing.Point(76, 724);
            this.PB_1_9.Name = "PB_1_9";
            this.PB_1_9.Size = new System.Drawing.Size(80, 80);
            this.PB_1_9.TabIndex = 207;
            this.PB_1_9.TabStop = false;
            this.PB_1_9.Visible = false;
            // 
            // PB_0_9
            // 
            this.PB_0_9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PB_0_9.Enabled = false;
            this.PB_0_9.Location = new System.Drawing.Point(0, 724);
            this.PB_0_9.Name = "PB_0_9";
            this.PB_0_9.Size = new System.Drawing.Size(80, 80);
            this.PB_0_9.TabIndex = 206;
            this.PB_0_9.TabStop = false;
            this.PB_0_9.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::PROYECTO_2_DABD_1249321_SKYNET_WAREHOUSE.Properties.Resources.bodega_fondo_2;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1390, 806);
            this.Controls.Add(this.PB_9_9);
            this.Controls.Add(this.PB_8_9);
            this.Controls.Add(this.PB_7_9);
            this.Controls.Add(this.PB_6_9);
            this.Controls.Add(this.PB_5_9);
            this.Controls.Add(this.PB_4_9);
            this.Controls.Add(this.PB_3_9);
            this.Controls.Add(this.PB_2_9);
            this.Controls.Add(this.PB_1_9);
            this.Controls.Add(this.PB_0_9);
            this.Controls.Add(this.PB_9_8);
            this.Controls.Add(this.PB_8_8);
            this.Controls.Add(this.PB_7_8);
            this.Controls.Add(this.PB_6_8);
            this.Controls.Add(this.PB_5_8);
            this.Controls.Add(this.PB_4_8);
            this.Controls.Add(this.PB_3_8);
            this.Controls.Add(this.PB_2_8);
            this.Controls.Add(this.PB_1_8);
            this.Controls.Add(this.PB_0_8);
            this.Controls.Add(this.PB_9_7);
            this.Controls.Add(this.PB_8_7);
            this.Controls.Add(this.PB_7_7);
            this.Controls.Add(this.PB_6_7);
            this.Controls.Add(this.PB_5_7);
            this.Controls.Add(this.PB_4_7);
            this.Controls.Add(this.PB_3_7);
            this.Controls.Add(this.PB_2_7);
            this.Controls.Add(this.PB_1_7);
            this.Controls.Add(this.PB_0_7);
            this.Controls.Add(this.PB_9_6);
            this.Controls.Add(this.PB_8_6);
            this.Controls.Add(this.PB_7_6);
            this.Controls.Add(this.PB_6_6);
            this.Controls.Add(this.PB_5_6);
            this.Controls.Add(this.PB_4_6);
            this.Controls.Add(this.PB_3_6);
            this.Controls.Add(this.PB_2_6);
            this.Controls.Add(this.PB_1_6);
            this.Controls.Add(this.PB_0_6);
            this.Controls.Add(this.PB_9_5);
            this.Controls.Add(this.PB_8_5);
            this.Controls.Add(this.PB_7_5);
            this.Controls.Add(this.PB_6_5);
            this.Controls.Add(this.PB_5_5);
            this.Controls.Add(this.PB_4_5);
            this.Controls.Add(this.PB_3_5);
            this.Controls.Add(this.PB_2_5);
            this.Controls.Add(this.PB_1_5);
            this.Controls.Add(this.PB_0_5);
            this.Controls.Add(this.PB_9_4);
            this.Controls.Add(this.PB_8_4);
            this.Controls.Add(this.PB_7_4);
            this.Controls.Add(this.PB_6_4);
            this.Controls.Add(this.PB_5_4);
            this.Controls.Add(this.PB_4_4);
            this.Controls.Add(this.PB_3_4);
            this.Controls.Add(this.PB_2_4);
            this.Controls.Add(this.PB_1_4);
            this.Controls.Add(this.PB_0_4);
            this.Controls.Add(this.PB_9_3);
            this.Controls.Add(this.PB_8_3);
            this.Controls.Add(this.PB_7_3);
            this.Controls.Add(this.PB_6_3);
            this.Controls.Add(this.PB_5_3);
            this.Controls.Add(this.PB_4_3);
            this.Controls.Add(this.PB_3_3);
            this.Controls.Add(this.PB_2_3);
            this.Controls.Add(this.PB_1_3);
            this.Controls.Add(this.PB_0_3);
            this.Controls.Add(this.PB_9_2);
            this.Controls.Add(this.PB_8_2);
            this.Controls.Add(this.PB_7_2);
            this.Controls.Add(this.PB_6_2);
            this.Controls.Add(this.PB_5_2);
            this.Controls.Add(this.PB_4_2);
            this.Controls.Add(this.PB_3_2);
            this.Controls.Add(this.PB_2_2);
            this.Controls.Add(this.PB_1_2);
            this.Controls.Add(this.PB_0_2);
            this.Controls.Add(this.PB_9_1);
            this.Controls.Add(this.PB_8_1);
            this.Controls.Add(this.PB_7_1);
            this.Controls.Add(this.PB_6_1);
            this.Controls.Add(this.PB_5_1);
            this.Controls.Add(this.PB_4_1);
            this.Controls.Add(this.PB_3_1);
            this.Controls.Add(this.PB_2_1);
            this.Controls.Add(this.PB_1_1);
            this.Controls.Add(this.PB_0_1);
            this.Controls.Add(this.PB_9_0);
            this.Controls.Add(this.PB_8_0);
            this.Controls.Add(this.PB_7_0);
            this.Controls.Add(this.PB_6_0);
            this.Controls.Add(this.PB_5_0);
            this.Controls.Add(this.PB_4_0);
            this.Controls.Add(this.PB_3_0);
            this.Controls.Add(this.PB_2_0);
            this.Controls.Add(this.PB_1_0);
            this.Controls.Add(this.PB_0_0);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Robot2);
            this.Controls.Add(this.Robot1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BTNReportes);
            this.Controls.Add(this.BTNIniciar);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.logo);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.logo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Robot1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Robot2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PB_0_0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_1_0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_2_0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_3_0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_4_0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_5_0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_6_0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_7_0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_8_0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_9_0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_9_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_8_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_7_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_6_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_5_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_4_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_3_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_2_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_1_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_0_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_9_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_8_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_7_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_6_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_5_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_4_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_3_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_2_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_1_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_0_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_9_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_8_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_7_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_6_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_5_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_4_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_3_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_2_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_1_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_0_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_9_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_8_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_7_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_6_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_5_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_4_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_3_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_2_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_1_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_0_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_9_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_8_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_7_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_6_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_5_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_4_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_3_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_2_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_1_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_0_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_9_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_8_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_7_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_6_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_5_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_4_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_3_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_2_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_1_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_0_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_9_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_8_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_7_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_6_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_5_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_4_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_3_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_2_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_1_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_0_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_9_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_8_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_7_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_6_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_5_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_4_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_3_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_2_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_1_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_0_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_9_9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_8_9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_7_9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_6_9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_5_9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_4_9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_3_9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_2_9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_1_9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_0_9)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button BTNIniciar;
        private System.Windows.Forms.Button BTNReportes;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox logo;
        private System.Windows.Forms.PictureBox Robot1;
        private System.Windows.Forms.PictureBox Robot2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem menuToolStripMenuItem;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.PictureBox PB_0_0;
        private System.Windows.Forms.PictureBox PB_1_0;
        private System.Windows.Forms.PictureBox PB_2_0;
        private System.Windows.Forms.PictureBox PB_3_0;
        private System.Windows.Forms.PictureBox PB_4_0;
        private System.Windows.Forms.PictureBox PB_5_0;
        private System.Windows.Forms.PictureBox PB_6_0;
        private System.Windows.Forms.PictureBox PB_7_0;
        private System.Windows.Forms.PictureBox PB_8_0;
        private System.Windows.Forms.PictureBox PB_9_0;
        private System.Windows.Forms.PictureBox PB_9_1;
        private System.Windows.Forms.PictureBox PB_8_1;
        private System.Windows.Forms.PictureBox PB_7_1;
        private System.Windows.Forms.PictureBox PB_6_1;
        private System.Windows.Forms.PictureBox PB_5_1;
        private System.Windows.Forms.PictureBox PB_4_1;
        private System.Windows.Forms.PictureBox PB_3_1;
        private System.Windows.Forms.PictureBox PB_2_1;
        private System.Windows.Forms.PictureBox PB_1_1;
        private System.Windows.Forms.PictureBox PB_0_1;
        private System.Windows.Forms.PictureBox PB_9_2;
        private System.Windows.Forms.PictureBox PB_8_2;
        private System.Windows.Forms.PictureBox PB_7_2;
        private System.Windows.Forms.PictureBox PB_6_2;
        private System.Windows.Forms.PictureBox PB_5_2;
        private System.Windows.Forms.PictureBox PB_4_2;
        private System.Windows.Forms.PictureBox PB_3_2;
        private System.Windows.Forms.PictureBox PB_2_2;
        private System.Windows.Forms.PictureBox PB_1_2;
        private System.Windows.Forms.PictureBox PB_0_2;
        private System.Windows.Forms.PictureBox PB_9_3;
        private System.Windows.Forms.PictureBox PB_8_3;
        private System.Windows.Forms.PictureBox PB_7_3;
        private System.Windows.Forms.PictureBox PB_6_3;
        private System.Windows.Forms.PictureBox PB_5_3;
        private System.Windows.Forms.PictureBox PB_4_3;
        private System.Windows.Forms.PictureBox PB_3_3;
        private System.Windows.Forms.PictureBox PB_2_3;
        private System.Windows.Forms.PictureBox PB_1_3;
        private System.Windows.Forms.PictureBox PB_0_3;
        private System.Windows.Forms.PictureBox PB_9_4;
        private System.Windows.Forms.PictureBox PB_8_4;
        private System.Windows.Forms.PictureBox PB_7_4;
        private System.Windows.Forms.PictureBox PB_6_4;
        private System.Windows.Forms.PictureBox PB_5_4;
        private System.Windows.Forms.PictureBox PB_4_4;
        private System.Windows.Forms.PictureBox PB_3_4;
        private System.Windows.Forms.PictureBox PB_2_4;
        private System.Windows.Forms.PictureBox PB_1_4;
        private System.Windows.Forms.PictureBox PB_0_4;
        private System.Windows.Forms.PictureBox PB_9_5;
        private System.Windows.Forms.PictureBox PB_8_5;
        private System.Windows.Forms.PictureBox PB_7_5;
        private System.Windows.Forms.PictureBox PB_6_5;
        private System.Windows.Forms.PictureBox PB_5_5;
        private System.Windows.Forms.PictureBox PB_4_5;
        private System.Windows.Forms.PictureBox PB_3_5;
        private System.Windows.Forms.PictureBox PB_2_5;
        private System.Windows.Forms.PictureBox PB_1_5;
        private System.Windows.Forms.PictureBox PB_0_5;
        private System.Windows.Forms.PictureBox PB_9_6;
        private System.Windows.Forms.PictureBox PB_8_6;
        private System.Windows.Forms.PictureBox PB_7_6;
        private System.Windows.Forms.PictureBox PB_6_6;
        private System.Windows.Forms.PictureBox PB_5_6;
        private System.Windows.Forms.PictureBox PB_4_6;
        private System.Windows.Forms.PictureBox PB_3_6;
        private System.Windows.Forms.PictureBox PB_2_6;
        private System.Windows.Forms.PictureBox PB_1_6;
        private System.Windows.Forms.PictureBox PB_0_6;
        private System.Windows.Forms.PictureBox PB_9_7;
        private System.Windows.Forms.PictureBox PB_8_7;
        private System.Windows.Forms.PictureBox PB_7_7;
        private System.Windows.Forms.PictureBox PB_6_7;
        private System.Windows.Forms.PictureBox PB_5_7;
        private System.Windows.Forms.PictureBox PB_4_7;
        private System.Windows.Forms.PictureBox PB_3_7;
        private System.Windows.Forms.PictureBox PB_2_7;
        private System.Windows.Forms.PictureBox PB_1_7;
        private System.Windows.Forms.PictureBox PB_0_7;
        private System.Windows.Forms.PictureBox PB_9_8;
        private System.Windows.Forms.PictureBox PB_8_8;
        private System.Windows.Forms.PictureBox PB_7_8;
        private System.Windows.Forms.PictureBox PB_6_8;
        private System.Windows.Forms.PictureBox PB_5_8;
        private System.Windows.Forms.PictureBox PB_4_8;
        private System.Windows.Forms.PictureBox PB_3_8;
        private System.Windows.Forms.PictureBox PB_2_8;
        private System.Windows.Forms.PictureBox PB_1_8;
        private System.Windows.Forms.PictureBox PB_0_8;
        private System.Windows.Forms.PictureBox PB_9_9;
        private System.Windows.Forms.PictureBox PB_8_9;
        private System.Windows.Forms.PictureBox PB_7_9;
        private System.Windows.Forms.PictureBox PB_6_9;
        private System.Windows.Forms.PictureBox PB_5_9;
        private System.Windows.Forms.PictureBox PB_4_9;
        private System.Windows.Forms.PictureBox PB_3_9;
        private System.Windows.Forms.PictureBox PB_2_9;
        private System.Windows.Forms.PictureBox PB_1_9;
        private System.Windows.Forms.PictureBox PB_0_9;
    }
}

