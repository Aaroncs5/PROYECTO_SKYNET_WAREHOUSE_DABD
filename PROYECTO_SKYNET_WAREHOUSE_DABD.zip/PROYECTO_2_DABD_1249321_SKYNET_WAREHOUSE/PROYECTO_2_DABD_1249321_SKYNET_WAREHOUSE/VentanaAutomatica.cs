﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PROYECTO_2_DABD_1249321_SKYNET_WAREHOUSE
{
    public partial class VentanaAutomatica : Form
    {
        public VentanaAutomatica()
        {
            InitializeComponent();
        }
    }
}
